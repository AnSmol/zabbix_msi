# package for ZABBIX Agent Client for Windows
# (C) 2011-2014   - Michel Manceron <michel.manceron@suiviperf.com>

# Content / Purpose
# -----------------
This package includes source code (precompiled W32 and w64 agent):
 . zabbix_agent for W32 & w64 - 
 . zabbix_sender.exe
 . zabbix_get.exe
  
# Credits
# -------
 . Vincent Besan�on - Thank's to nullsoft NSIS magic
 . ZABBIX SIA of course
 
# Links
# -----
 . ZABBIX SIA : http://www.zabbix.com/download/
 . Zabbix Agent installer : http://www.suiviperf.com/zabbix/


 